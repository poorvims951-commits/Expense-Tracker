# SpendWise — Flask Mini Project

A polished, beginner-friendly expense tracker built with Python Flask, HTML templates, and CSS.

## 1. Problem the application solves
SpendWise helps a user record everyday expenses, group them into categories, and review a dashboard summary of recorded spending.

## 2. Features
- Dashboard showing total recorded spending, transaction count, category breakdown, and recent transactions.
- Add an expense through a form.
- Input validation with friendly error messages.
- View and remove transactions.
- About page explaining the project and its routes.
- Responsive layout for desktop and mobile screens.
- Custom 404 page.

## 3. Folder structure

```text
SpendWise_Flask_Mini_Project/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── expenses.html
│   ├── about.html
│   └── 404.html
└── static/
    └── style.css
```

## 4. Requirements
- Python 3.9 or newer
- pip
- A modern web browser

## 5. Run the application

Open a terminal in this project folder.

### Windows

```bash
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open the local address shown in the terminal, normally `http://127.0.0.1:5000`.

## 6. Routes

| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Displays the dashboard and summary |
| `/about` | GET | Shows project information |
| `/expenses` | GET | Displays the expense form and transaction list |
| `/expenses` | POST | Validates and saves an expense |
| `/delete/<id>` | POST | Removes an expense |
| Unknown URL | GET | Displays the custom 404 page |

## 7. Validation and error handling
- Expense name is required and limited to 60 characters.
- Category must be one of the available categories.
- Amount must be numeric, greater than zero, and within the configured limit.
- Date must be valid.
- Notes are limited to 140 characters.
- A friendly message is displayed when input is invalid.

## 8. Testing checklist

- [ ] Run `python app.py` without errors.
- [ ] Open `/` and verify that the dashboard loads.
- [ ] Open `/about` and verify that project information appears.
- [ ] Open `/expenses` and add a valid expense.
- [ ] Try submitting an empty expense name.
- [ ] Try entering zero, a negative number, or non-numeric amount.
- [ ] Verify the success message and updated totals.
- [ ] Remove an expense and confirm it disappears.
- [ ] Open an unknown URL and verify the 404 page.
- [ ] Restart the app and note that demo entries reset.

## 9. Important implementation note
This beginner project stores entries in a Python list in memory. It does not use a database, authentication, deployment, or secret keys. The entries reset when the application restarts. A few sample expenses are included so the dashboard is not empty on first launch.

## 10. Concepts demonstrated
Flask routes, GET and POST methods, HTML forms, request data, input validation, Jinja template inheritance and loops, redirects, static CSS files, and a custom error handler.
