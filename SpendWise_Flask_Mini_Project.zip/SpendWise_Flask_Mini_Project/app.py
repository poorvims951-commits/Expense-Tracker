from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

# Beginner-friendly in-memory storage.
# Entries reset when the application is restarted; no database is required.
expenses = [
    {"id": 1, "title": "Weekly groceries", "category": "Food", "amount": 850.00, "date": "2026-10-24", "note": "Essentials for the week"},
    {"id": 2, "title": "Metro & bus", "category": "Transport", "amount": 220.00, "date": "2026-10-23", "note": "Daily commute"},
    {"id": 3, "title": "Coffee with friends", "category": "Lifestyle", "amount": 180.00, "date": "2026-10-22", "note": "Weekend catch-up"},
    {"id": 4, "title": "Notebook and pens", "category": "Education", "amount": 145.00, "date": "2026-10-20", "note": "Study supplies"},
]
next_id = 5
CATEGORIES = ["Food", "Transport", "Education", "Bills", "Lifestyle", "Health", "Other"]


def dashboard_data():
    total = sum(item["amount"] for item in expenses)
    category_totals = {}
    for item in expenses:
        category_totals[item["category"]] = category_totals.get(item["category"], 0) + item["amount"]
    category_rows = [
        {"name": name, "amount": amount, "percent": round((amount / total) * 100) if total else 0}
        for name, amount in sorted(category_totals.items(), key=lambda pair: pair[1], reverse=True)
    ]
    recent = sorted(expenses, key=lambda item: (item["date"], item["id"]), reverse=True)
    return total, category_rows, recent


@app.route("/")
def home():
    total, category_rows, recent = dashboard_data()
    return render_template(
        "index.html",
        total=total,
        category_rows=category_rows,
        recent=recent,
        categories=CATEGORIES,
        expense_count=len(expenses),
        today=datetime.now().strftime("%d %b %Y"),
    )


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/expenses", methods=["GET", "POST"])
def expense_list():
    global next_id
    error = None
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "").strip()
        amount_text = request.form.get("amount", "").strip()
        date = request.form.get("date", "").strip()
        note = request.form.get("note", "").strip()

        if not title:
            error = "Please enter a name for this expense."
        elif len(title) > 60:
            error = "Expense name must be 60 characters or fewer."
        elif category not in CATEGORIES:
            error = "Please choose a valid category."
        else:
            try:
                amount = float(amount_text)
                if amount <= 0:
                    error = "Amount must be greater than ₹0."
                elif amount > 10000000:
                    error = "Please enter an amount below ₹1,00,00,000."
            except (ValueError, TypeError):
                error = "Enter a valid amount, such as 250 or 250.50."

        if not error and not date:
            date = datetime.now().strftime("%Y-%m-%d")
        if not error:
            try:
                datetime.strptime(date, "%Y-%m-%d")
            except ValueError:
                error = "Please select a valid date."

        if not error:
            expenses.append({
                "id": next_id,
                "title": title,
                "category": category,
                "amount": round(amount, 2),
                "date": date,
                "note": note[:140],
            })
            next_id += 1
            return redirect(url_for("expense_list", added="1"))

    total, category_rows, recent = dashboard_data()
    return render_template(
        "expenses.html",
        expenses=recent,
        total=total,
        categories=CATEGORIES,
        error=error,
        added=request.args.get("added") == "1",
        today=datetime.now().strftime("%Y-%m-%d"),
    )


@app.route("/delete/<int:expense_id>", methods=["POST"])
def delete_expense(expense_id):
    """Remove an expense using a POST form."""
    for item in expenses:
        if item["id"] == expense_id:
            expenses.remove(item)
            break
    return redirect(url_for("expense_list", deleted="1"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True)
